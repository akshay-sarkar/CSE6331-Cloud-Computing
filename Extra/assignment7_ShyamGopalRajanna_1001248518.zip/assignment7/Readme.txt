AWS app deployed link -

http://ec2-54-193-77-186.us-west-1.compute.amazonaws.com:5000/

submitted by - ShyamGopalRajanna (1001248518)