ext_id = 'oldext_simple'
